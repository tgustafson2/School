/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BaseGame.h
 * Author: tgust
 *
 * Created on June 3, 2019, 9:39 PM
 */

#ifndef BASEGAME_H
#define BASEGAME_H

#include "Player.h"


using namespace std;
//ostream &operator << (ostream &, const BaseGame &);
enum Axislab{
    A,B,C,D,E,F,G,H,I,J};
class BaseGame{
protected:
    Player *players;
    
    static Axislab conv(char);
public:
    BaseGame(int playernum){
        players= new Player[playernum]{playernum};
        players[0].setPlayercount(playernum);
        players[0].setStartingPlayers(playernum);
    }
    ~BaseGame(){
        delete []players;
    }
    /*void setOccupied(){
        players->setOccupied();
    }*/
    int getOccupied(int p, int i, int j)const{
        return players[p].getOccupied(i,j);
    }
    void setMark(int p, string mark, int i, int j){
        players[p].setMark(mark, i, j);
    }
    string getMark(int p, int i, int j)const{
        return players[p].getMark(i,j);
    }
    void setActive(int p, bool active){
        players[p].setActive(active);
    }
    bool getActive(int p)const{
        return players[p].getActive();
    }
    void setPlayercount(int p, int playernum){
        players[p].setPlayercount(playernum);
    }
    int getPlayercount()const{
        return Player::getPlayercount();
    }
    string getName(int i)const{
        return players[i].getName();
    }
    int getStartingplayer()const{
        return Player::getStartingPlayers();
    }
    bool attack(string , char , int );
    friend ostream &operator << (ostream &, const BaseGame &);
    friend void Player::setOccupied();
};


#endif /* BASEGAME_H */

