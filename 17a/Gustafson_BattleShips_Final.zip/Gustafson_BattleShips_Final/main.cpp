/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: tgust
 *
 * Created on June 3, 2019, 5:27 PM
 */

#include <cstdlib>
#include "BaseGame.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int players;
    cout<<"Enter the number of players:";
    cin>>players;
    cin.ignore();
    
    BaseGame battleships(players);
        while (battleships.getPlayercount()>1){
        for (int q=0; q< players; q++){
        //for (int p=0; p<num_players; p++){
        //    display (&plyrs[p]);
        //}
        //output boards with operator overloading
            cout<<battleships;
    
        if (battleships.getActive(q)==true){
            string pname;
            
            int tracker, acol;
            char arow;
            do{
                cout<<"Enter the player's name you want to hit:";
              
                cin>>pname;
                cin.ignore();
                while (pname!=battleships.getName(0)&&pname!=battleships.getName(1)
                        &&pname!=battleships.getName(2)&&pname!=battleships.getName(3)
                        &&pname!=battleships.getName(4)&&pname!=battleships.getName(5)){
                    cout<<"Invalid name. Reeneter name:";
                    cin>>pname;
                }
                
                
                cout<<"Enter the row you want to hit:";
                cin>>arow;
                if(arow<'a' || arow>'j'){
            if(arow<'A' || arow>'J'){
                cout<<"Invalid input. Reenter row:";
                cin>>arow;
            }
        }
                cout<<"Enter the column you want to hit:";
                cin>>acol;
                 if (acol<0||acol>9){
            cout<<"Invalid input. Reenter column:";
            cin>>acol;
        }

            }while(battleships.attack(pname,arow,acol)==true);

        }
        
     
     }
    }
    for (int i; i<players; i++){
        if (battleships.getActive(i)==true){
            cout<<"Congratulations "<<battleships.getName(i)<<", you have won.";
        }
    }

    return 0;
}

