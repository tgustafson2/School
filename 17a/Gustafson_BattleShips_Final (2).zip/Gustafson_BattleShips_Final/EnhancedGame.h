/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   EnhancedGame.h
 * Author: tgust
 *
 * Created on June 3, 2019, 9:39 PM
 */

#ifndef ENHANCEDGAME_H
#define ENHANCEDGAME_H
#include <iostream>
#include "BaseGame.h"


using namespace std;

class EnhancedGame: public BaseGame{
private:
    int commander[2];
public:
    EnhancedGame():BaseGame(2){
        commander[0]=0;
        commander[1]=0;
    }
    void setCommander(int i, int j){
        commander[i]=j;
    }
    int getCommander(int i){
        return commander[i];
    }
    void radar(string, char, int);
    void mine(int, char, int);
    void linebomb(string, char, int);
    void gridbomb(string, char, int);
    bool attack(string , char , int , int&);
    friend ostream &operator << (ostream &, const EnhancedGame &);
};

#endif /* ENHANCEDGAME_H */

