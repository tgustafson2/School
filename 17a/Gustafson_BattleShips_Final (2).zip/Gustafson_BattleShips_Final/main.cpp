/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: tgust
 *
 * Created on June 3, 2019, 5:27 PM
 */

#include <cstdlib>
#include "BaseGame.h"
#include "EnhancedGame.h"

using namespace std;

/*
 * 
 */
void basegame();
void enhanced();
int main(int argc, char** argv) {
    cout<<"Would you like to play the basic battleships or the enhanced version?"<<endl;
    cout<<"1 for basic, 2 for enhanced";
    int choice;
    cin>>choice;
    cin.ignore();
    switch (choice){
        case 1: basegame();break;
        case 2: enhanced();break;
    }


    return 0;
}
void basegame(){
        int players;
    cout<<"Enter the number of players:";
    cin>>players;
    int playcount=players;
    cin.ignore();
   

    BaseGame battleships(players);
    cout<<playcount;
    //cout<<battleships.getPlayercount();
        while (playcount>1){
            //cout<<"Start of while loop";
            
        for (int q=0; q< players; q++){
        //for (int p=0; p<num_players; p++){
        //    display (&plyrs[p]);
        //}
        //output boards with operator overloading
            cout<<battleships.getPlayercount()<<endl;
            cout<<battleships;
    
        if (battleships.getActive(q)==true){
           
            string pname;
            
            int tracker, acol;
            char arow;
            do{
                cout<<battleships.getName(q)<<" enter the player's name you want to attack:";
              
                cin>>pname;
                cin.ignore();
                while (pname!=battleships.getName(0)&&pname!=battleships.getName(1)
                        &&pname!=battleships.getName(2)&&pname!=battleships.getName(3)
                        &&pname!=battleships.getName(4)&&pname!=battleships.getName(5)){
                    cout<<"Invalid name. Reeneter name:";
                    cin>>pname;
                    cin.ignore();
                }
                
                
                cout<<"Enter the row you want to hit:";
                cin>>arow;
                if(arow<'a' || arow>'j'){
            if(arow<'A' || arow>'J'){
                cout<<"Invalid input. Reenter row:";
                cin>>arow;
            }
        }
                cout<<"Enter the column you want to hit:";
                cin>>acol;
                 if (acol<0||acol>9){
            cout<<"Invalid input. Reenter column:";
            cin>>acol;
        }

            }while(battleships.attack(pname,arow,acol, playcount)==true);

        }
            //cout<<"After if attack loop"<<endl;
        
     
     }
    }
    cout<<"End of Game";
    for (int i; i<players; i++){
        if (battleships.getActive(i)==true){
            cout<<"End of game";
            cout<<"Congratulations "<<battleships.getName(i)<<", you have won.";
        }
    }
}
void enhanced(){
        int players;
    cout<<"This is only a 2 person mode"<<endl;
    players=2;
    //int playcount=players;
    
   

    int choice;
    EnhancedGame battleships(players);
    cout<<"Player 1 choose your commander";
    cin>>choice;
    cin.ignore();
    battleships.setCommander(0,choice);
    cout<<"Player 2 choose your commander";
    cin>>choice;
    cin.ignore();
    battleships.setCommander(1, choice);
    //cout<<playcount;
    //cout<<battleships.getPlayercount();
        while (battleships.getPlayercount()>1){
            //cout<<"Start of while loop";
            
        for (int q=0; q< players; q++){
        //for (int p=0; p<num_players; p++){
        //    display (&plyrs[p]);
        //}
        //output boards with operator overloading
            cout<<battleships.getPlayercount()<<endl;
            cout<<battleships;
            string pname;
            int tracker, acol;
            char arow;
        if (battleships.getActive(q)==true){
            cout<<"Would you like to attack or use a special ability?1 for ability 2 for attack:";
            cin>>choice;
            cin.ignore();
            if(choice==1){
                if(battleships.getCommander(q)==1){
                    cout<<"Would you like to use radar a mine or an area attack? Enter 1, 2, or 3:"
                            cin<<choice;
                    cin.ignore();
                    if (choice==1){
                        cout<<"Enter the name of person you want to radar:";
                        cin>>pname;
                        cin.ignore();
                        while (pname!=battleships.getName(0)&&pname!=battleships.getName(1)
                        &&pname!=battleships.getName(2)&&pname!=battleships.getName(3)
                        &&pname!=battleships.getName(4)&&pname!=battleships.getName(5)){
                    cout<<"Invalid name. Reeneter name:";
                    cin>>pname;
                    cin.ignore();
                }
                
                
                cout<<"Enter the row you want to radar:";
                cin>>arow;
                if(arow<'a' || arow>'j'){
            if(arow<'A' || arow>'J'){
                cout<<"Invalid input. Reenter row:";
                cin>>arow;
            }
        }
                cout<<"Enter the column you want to radar:";
                cin>>acol;
                 if (acol<0||acol>9){
            cout<<"Invalid input. Reenter column:";
            cin>>acol;
                    }
                    else if (choice==2){
                        cout<<"Enter the location you want to place a mine";
                  cout<<"Enter the row you want to mine:";
                cin>>arow;
                if(arow<'a' || arow>'j'){
            if(arow<'A' || arow>'J'){
                cout<<"Invalid input. Reenter row:";
                cin>>arow;
            }
        }
                cout<<"Enter the column you want to mine:";
                cin>>acol;
                 if (acol<0||acol>9){
            cout<<"Invalid input. Reenter column:";
            cin>>acol;                      
                    }
                battleships.mine(q, arow, acol);
                }
                else if (battleships.getCommander(q)==2){
                    cout<<"Would you like to use radar a mine or an line attack? Enter 1, 2, or 3:"
                            cin<<choice;
                    cin.ignore();
            if(choice==1){
                if(battleships.getCommander(q)==1){
                    cout<<"Would you like to use radar a mine or an area attack? Enter 1, 2, or 3:"
                            cin<<choice;
                    cin.ignore();
                    if (choice==1){
                        cout<<"Enter the name of person you want to radar:";
                        cin>>pname;
                        cin.ignore();
                        while (pname!=battleships.getName(0)&&pname!=battleships.getName(1)
                        &&pname!=battleships.getName(2)&&pname!=battleships.getName(3)
                        &&pname!=battleships.getName(4)&&pname!=battleships.getName(5)){
                    cout<<"Invalid name. Reeneter name:";
                    cin>>pname;
                    cin.ignore();
                }
                
                
                cout<<"Enter the row you want to radar:";
                cin>>arow;
                if(arow<'a' || arow>'j'){
            if(arow<'A' || arow>'J'){
                cout<<"Invalid input. Reenter row:";
                cin>>arow;
            }
        }
                cout<<"Enter the column you want to radar:";
                cin>>acol;
                 if (acol<0||acol>9){
            cout<<"Invalid input. Reenter column:";
            cin>>acol;
                    }
                    else if (choice==2){
                        cout<<"Enter the location you want to place a mine";
                  cout<<"Enter the row you want to mine:";
                cin>>arow;
                if(arow<'a' || arow>'j'){
            if(arow<'A' || arow>'J'){
                cout<<"Invalid input. Reenter row:";
                cin>>arow;
            }
        }
                cout<<"Enter the column you want to mine:";
                cin>>acol;
                 if (acol<0||acol>9){
            cout<<"Invalid input. Reenter column:";
            cin>>acol;                      
                    }
                battleships.mine(q, arow, acol);
                }                    
                }
                }}}
            

            
           // int tracker, acol;
            //char arow;
            do{
                cout<<battleships.getName(q)<<" enter the player's name you want to attack:";
              
                cin>>pname;
                cin.ignore();
                while (pname!=battleships.getName(0)&&pname!=battleships.getName(1)
                        &&pname!=battleships.getName(2)&&pname!=battleships.getName(3)
                        &&pname!=battleships.getName(4)&&pname!=battleships.getName(5)){
                    cout<<"Invalid name. Reeneter name:";
                    cin>>pname;
                    cin.ignore();
                }
                
                
                cout<<"Enter the row you want to hit:";
                cin>>arow;
                if(arow<'a' || arow>'j'){
            if(arow<'A' || arow>'J'){
                cout<<"Invalid input. Reenter row:";
                cin>>arow;
            }
        }
                cout<<"Enter the column you want to hit:";
                cin>>acol;
                 if (acol<0||acol>9){
            cout<<"Invalid input. Reenter column:";
            cin>>acol;
        }

            }while(battleships.attack(pname,arow,acol)==true);

        }
            //cout<<"After if attack loop"<<endl;
        
     
     }
    }
    cout<<"End of Game";
    for (int i; i<players; i++){
        if (battleships.getActive(i)==true){
            cout<<"End of game";
            cout<<"Congratulations "<<battleships.getName(i)<<", you have won.";
        }
    }
}
        }
}
