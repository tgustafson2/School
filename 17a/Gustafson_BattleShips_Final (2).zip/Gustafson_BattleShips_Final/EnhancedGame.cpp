/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "EnhancedGame.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

bool EnhancedGame::attack(string name, char row, int col, int &playcount){
        Axislab rowconv=conv(row);
        int tracker;
                if(name==getName(0)){
                    tracker=0;
                }
                else if (name==getName(1)){
                    tracker=1;
                }
                else if (name==getName(2)){
                    tracker=2;
                }
                else if (name==getName(3)){
                    tracker=3;
                }
                else if (name==getName(4)){
                    tracker=4;
                }
                else if (name==getName(5)){
                    tracker=5;
                }
        if (players[tracker]->getOccupied(rowconv, col)==true){
            
            players[tracker]->setMark("hit",rowconv, col);
            players[tracker]->subtractPieces(1);
            cout<<players[tracker]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[tracker]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                playcount--;
                players[tracker]->setActive(false);
            }
            if (playercount==1){
                return false;
            }
            return true;
        }
        else if (players[tracker]->getOccupied(rowconv, col)==false){
           
                                if (players[tracker]->getMark(rowconv,col)="mine"){
                                    int att;
                        if (tracker==0) att=1;
                        else if (tracker==1) att=0;
                        if (players[att]->getOccupied(rand()%9, rand()%8)==true){
            players[att]->setMark("hit",rand()%9, rand()%9);
            players[att]->subtractPieces(1);
            cout<<players[att]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[att]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                
                players[att]->setActive(false);
            }

        }
                    }
                                else                     
            players[tracker]->setMark("miss", rowconv, col);
            return false;
        }
    }
ostream & operator <<(ostream &strm, const BaseGame &obj){
    
    for (int i=0; i<obj.startingplayers; i++){
        strm<<obj.getName(i)<<endl;
                    for (int x =0;x<10; x++){
      if (x==0){strm<<"  0  1  2  3  4  5  6  7  8  9"<<endl;}
       if (x==0){ strm<<"A ";}
                    
                    else if(x==1){ strm<<"B ";}
                    
                    else if(x==2){ strm<<"C ";}
                    
                    
                    else if (x==3){ strm<<"D ";}
                    
                    else if (x==4){ strm<<"E ";}
                    
                    else if (x==5){ strm<<"F ";}
                    
                    else if (x==6){ strm<<"G ";}
                    
                    else if (x==7){ strm<<"H ";}
                    
                    else if (x==8){ strm<<"I ";}
                   
                    else if (x==9){ strm<<"J ";}
     for (int y=0; y<10; y++){
     
              
                    
      
                if (obj.getMark(i,x,y)=="miss"){
      strm<<"O  ";}
                else if (obj.getMark(i,x,y)=="hit"){
      strm<<"X  ";}
                else if (obj.getMark(i,x,y)>="0"&& obj.getMark(i,x,y)<="9"){
                    strm<<obj.getMark(i,x,y)<<" ";
                }
                else{
                    strm<<"___";
                }
      
      
     
                }
      cout<<endl;
            }
    }
}
void EnhancedGame::radar(string name, char row, int col){
    Axislab rowconv=conv(row);
    int tracker;
                    if(name==getName(0)){
                    tracker=0;
                }
                else if (name==getName(1)){
                    tracker=1;
                }
    int occ;
            for (int j=rowconv-1; j<=rowconv+1; j=static_cast<Axislab>(j+1)){
                if (players[tracker]->getOccupied(j, col)==true){
                    tracker++;
                }
            }
    string occu=to_string(occ);
    players[tracker]->setMark(occu, rowconv, col);
    
}
void EnhancedGame::mine(int i,char row, int col){
    Axislab rowconv=conv(row);
    players[i]->setMark("mine",rowconv,col);
    
}
void EnhancedGame::linebomb(string name, char row, int col){
    Axislab rowconv=conv(row);
            Axislab rowconv=conv(row);
        int tracker;
                if(name==getName(0)){
                    tracker=0;
                }
                else if (name==getName(1)){
                    tracker=1;
                }
        int att;
        if (rowconv=A){
            for (int j=rowconv; j<=rowconv+8; j=static_cast<Axislab>(j+1)){
                if (players[tracker]->getOccupied(j, col)==true){
                    if (players[tracker]->getMark(rowconv,col)="mine"){
                        if (tracker==0) att=1;
                        else if (tracker==1) att=0;
                        if (players[att]->getOccupied(rand()%9, rand()%8)==true){
            players[att]->setMark("hit",rand()%9, rand()%9);
            players[att]->subtractPieces(1);
            cout<<players[att]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[att]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                
                players[att]->setActive(false);
            }

        }
                    }
                    else
                                players[tracker]->setMark("hit",j, col);
            players[tracker]->subtractPieces(1);
            cout<<players[tracker]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[tracker]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                
                players[tracker]->setActive(false);
            }
        else if (players[tracker]->getOccupied(rowconv, col)==false){
            players[tracker]->setMark("miss", j, col);

        }

        }
                }
                
            }
        else{
            for (int i=0; i<10; i++){
                if (players[tracker]->getOccupied(rowconv, i)==true){
                    if (players[tracker]->getMark(rowconv,i)="mine"){
                        if (tracker==0) att=1;
                        else if (tracker==1) att=0;
                        if (players[att]->getOccupied(rand()%9, rand()%8)==true){
            players[att]->setMark("hit",rand()%9, rand()%9);
            players[att]->subtractPieces(1);
            cout<<players[att]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[att]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                
                players[att]->setActive(false);
            }

        }
                    }
                    else
                                players[tracker]->setMark("hit",rowconv, i);
            players[tracker]->subtractPieces(1);
            cout<<players[tracker]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[tracker]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                
                players[tracker]->setActive(false);
            }
        else if (players[tracker]->getOccupied(rowconv, i)==false){
            players[tracker]->setMark("miss", rowconv, i);

        }

        }
                }
        }
}
void EnhancedGame:: gridbomb(string name, char row, int col){
    Axislab rowconv=conv(row);
    unsigned seed=time(0);
    srand (seed);
            Axislab rowconv=conv(row);
        int tracker;
                if(name==getName(0)){
                    tracker=0;
                }
                else if (name==getName(1)){
                    tracker=1;
                }
        int att;
        for (int i= col-1; i<=col+1; i++){
            for (int j=rowconv-1; j<=rowconv+1; j=static_cast<Axislab>(j+1)){
                if (players[tracker]->getOccupied(j, i)==true){
                    if (players[tracker]->getMark(rowconv, i)="mine"){
                        if (tracker==0) att=1;
                        else if (tracker==1) att=0;
                        if (players[att]->getOccupied(rand()%9, rand()%8)==true){
            players[att]->setMark("hit",rand()%9, rand()%9);
            players[att]->subtractPieces(1);
            cout<<players[att]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[att]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                
                players[att]->setActive(false);
            }

        }
                    }
                    else
                                players[tracker]->setMark("hit",j, i);
            players[tracker]->subtractPieces(1);
            cout<<players[tracker]->getPieces()<<endl;
            cout<<"Hit"<<endl;
            
            if (players[tracker]->getPieces()==0){
                //cout<<playercount<<"in if loop"<<endl;
                playercount--;
                
                players[tracker]->setActive(false);
            }
        else if (players[tracker]->getOccupied(rowconv, col)==false){
            players[tracker]->setMark("miss", j, i);

        }

        }
                }
        }
            
}