/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Battleships.h
 * Author: tgust
 *
 * Created on October 12, 2019, 3:36 PM
 */

#ifndef BATTLESHIPS_H
#define BATTLESHIPS_H

class Battleships{
private:
    //*Players
public:
    //constructor call players objectaray
    //game alternate until one player is no longer active, display winner name
};


#endif /* BATTLESHIPS_H */

