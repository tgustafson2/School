/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: tgust
 *
 * Created on October 12, 2019, 3:36 PM
 */

#ifndef PLAYER_H
#define PLAYER_H

class Player{
private:
    //board
    //active status
public:
    //constructor call board, then prompt input for ships positions, use lists for ships
    //check status
    //getboard location
    //setboard string
    //printboard function
};


#endif /* PLAYER_H */

