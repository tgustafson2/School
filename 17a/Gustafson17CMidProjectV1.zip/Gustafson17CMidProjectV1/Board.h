/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Board.h
 * Author: tgust
 *
 * Created on October 12, 2019, 3:36 PM
 */

#ifndef BOARD_H
#define BOARD_H

class Board{
private:
    //use map for board
public:
    //set all strings to empty in constructor
    //setstring function
    //getoccupied function
    //printboard
    
};

#endif /* BOARD_H */

